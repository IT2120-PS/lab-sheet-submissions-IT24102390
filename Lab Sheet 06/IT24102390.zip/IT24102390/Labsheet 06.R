getwd()
setwd("C:\\Users\\DELL\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24102390")

#Question 1

#Binomial distribution with n=50 and p=0.85
#Here, random variable X has binomial distribution with n=50 and p=0.85


#Probability P(X >= 47)
#Use 1- P(X<= 46) to find P(X>=47)
1-pbinom(46,50,0.85,lower.tail=TRUE)

#Part 2 
#Number of customer calls received in an hour
#Poisson distribution with lambda=12
#Here, random variable X has poisson distribution with lambda=12
#Probability P(X=15)
dpois(15,12)
